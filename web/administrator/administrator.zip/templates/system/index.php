<?php
/**
 * @version		$Id: index.php 21389 2011-05-26 17:28:26Z dextercowley $
 * @copyright	Copyright (C) 2005 - 2011 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

include dirname(__FILE__).DIRECTORY_SEPARATOR.'component.php';
?>